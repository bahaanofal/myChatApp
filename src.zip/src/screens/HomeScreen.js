import React, { useEffect, useState } from 'react';
import { Text, View, Image, StyleSheet, TouchableOpacity } from 'react-native';
import firestore from '@react-native-firebase/firestore';
import { FlatList } from 'react-native-gesture-handler';
import { FAB } from 'react-native-paper';

export default function HomeScreen({ user, navigation }) {
    // console.log(user);
    const [users, setUsers] = useState(null);
    const getUsers = async () => {
        const querySnap = await firestore().collection('users').where('uid', '!=', user.uid).get();
        const allUsers = querySnap.docs.map(docSnap => docSnap.data());
        setUsers(allUsers);
        // console.log(allUsers);
    }

    useEffect(() => {
        getUsers();
    }, []);

    const RenderCard = ({ item }) => {

        return (
            <TouchableOpacity onPress={() => navigation.navigate('Chat', {
                name: item.name,
                uid: item.uid,
                pic: item.picture,
                // status: typeof(item.status) == "string" ? item.status : 'not online'
                status: typeof (item.status) == "string" ? item.status : JSON.stringify(item.status.toDate())
            })}>
                <View style={styles.myCard}>
                    <Image source={{ uri: item.picture }} style={styles.img} />
                    <View>
                        <Text style={styles.title}>{item.name}</Text>
                        <Text style={styles.text}>{item.email}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        );
    }

    return (
        <View style={{ backgroundColor: 'white', flex: 1 }}>
            <FlatList
                data={users}
                renderItem={({ item }) => <RenderCard item={item} />}
                keyExtractor={(item) => item.uid}
            />
            <FAB
                style={styles.fab}
                icon="face-man-profile"
                onPress={() => navigation.navigate('profile') }
            />
        </View>
    )
}

const styles = StyleSheet.create({
    img: {
        width: 60,
        height: 60,
        borderRadius: 30,
        backgroundColor: 'green'
    },
    text: {
        fontSize: 17,
        marginLeft: 15
    },
    title: {
        color: 'black',
        fontSize: 19,
        marginLeft: 15,
    },
    myCard: {
        display: 'flex',
        flexDirection: 'row',
        margin: 3,
        padding: 4,
        backgroundColor: 'white',
    },
    fab: {
        position: 'absolute',
        margin: 16,
        right: 0,
        bottom: 0,
        backgroundColor: 'white'
    },
});