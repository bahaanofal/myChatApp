import React, { useState, useEffect } from 'react';
import { View, Text, ActivityIndicator, Image, StyleSheet, TouchableOpacity } from 'react-native';
import firestore from '@react-native-firebase/firestore';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import { Button } from 'react-native-paper';
import auth from '@react-native-firebase/auth';

export default function AccountScreen({ user, navigation }) {
    const [profile, setProfile] = useState('');

    useEffect(() => {
        firestore().collection('users').doc(user.uid).get().then(docSnap => {
            setProfile(docSnap.data())
        })
    }, []);

    if (!profile) {
        return <ActivityIndicator size="large" color="#00ff00" />
    }

    return (
        <View style={styles.container}>
            <View style={styles.imageContainer}>
                <Image source={{ uri: profile.picture }} style={styles.img} />
            </View>
            <View style={styles.textContainer}>
                <View style={styles.row}>
                    <MaterialIcons name='account-circle' size={30} />
                    <Text style={styles.text}>{profile.name}</Text>
                </View>
                <View style={styles.row}>
                    <MaterialIcons name='email' size={30} />
                    <Text style={styles.text}>{profile.email}</Text>
                </View>
            </View>
            <Button
                mode='contained'
                onPress={() => {
                    firestore().collection('users').doc(user.uid).update({
                        status: firestore.FieldValue.serverTimestamp()
                    }).then(() => {
                        auth().signOut()
                    })
                }}
                style={styles.btn}>
                logout
            </Button>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        height: 450,
        justifyContent: "space-evenly",
    },
    imageContainer: {
        alignItems: 'center'
    },
    img: {
        width: 200,
        height: 200,
        borderRadius: 100,
        borderWidth: 3,
        borderColor: 'white',
    },
    textContainer: {
        height: 150,
        justifyContent: "space-evenly",
        paddingLeft: 30,
    },
    row: {
        flexDirection: 'row',
    },
    text: {
        fontSize: 23,
        marginLeft: 15,
    },
    btn: {
        borderColor: "white",
        borderWidth: 3,
        width: '50%',
        marginLeft: '24%',
        backgroundColor: '#707070'
    },

});
