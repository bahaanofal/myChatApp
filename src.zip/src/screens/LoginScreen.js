import React, { useState } from 'react'
import { Text, View, Image, StyleSheet, KeyboardAvoidingView, TouchableOpacity, ActivityIndicator } from 'react-native'
import { TextInput, Button } from 'react-native-paper';
import auth from '@react-native-firebase/auth'
import firestore from '@react-native-firebase/firestore';


export default function SignupScreen({ navigation }) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);

    if (loading) {
        return <ActivityIndicator size="large" color="#00ff00" />
    }
    const userLogin = async () => {
        setLoading(true);
        if (!email || !password) {
            alert('please add the all fields!!');
            setLoading(false);
            return;
        }

        try {
            navigation.navigate('Home');

            // const result = await auth().signInWithEmailAndPassword(email, password);
         
            // setLoading(false);
            // navigation.navigate('Home');
        } catch (error) {
            alert('something went wrong!');
            setLoading(false);
        }
    }

    return (
        <View style={{ backgroundColor: 'white', height: '100%', paddingTop: '10%' }}>
            <KeyboardAvoidingView behavior='position'>
                <View style={styles.box1}>
                    <Text style={styles.text}>Welcome To Whatsapp</Text>
                    <Image style={styles.img} source={require('../assets/welcome.png')} resizeMode='cover' />
                </View>
                <View style={styles.box2}>
                    <TextInput
                        label='Email'
                        value={email}
                        onChangeText={(text) => setEmail(text)}
                        style={{
                            borderBottomColor: 'green',
                            backgroundColor: 'white',
                            marginTop: 10,
                        }}
                    />
                    <TextInput
                        label='Password'
                        value={password}
                        onChangeText={(text) => setPassword(text)}
                        secureTextEntry
                        style={{
                            borderBottomColor: 'green',
                            backgroundColor: 'white',
                            marginTop: 10,
                        }}
                    />
                    <Button
                        mode='contained'
                        onPress={() => userLogin()}
                        style={{ marginTop: 20 }}>
                        Login
                    </Button>
                    <TouchableOpacity><Text onPress={() => navigation.navigate('Signup')} style={{ textAlign: 'center', marginTop: 20 }}>Dont have an account ? Sign up</Text></TouchableOpacity>
                </View>
            </KeyboardAvoidingView>
        </View>
    )
}

const styles = StyleSheet.create({
    text: {
        fontSize: 22,
        color: 'green',
        margin: 10
    },
    img: {
        width: 180,
        height: 180,
        marginTop: 10
    },
    box1: {
        alignItems: 'center',

    },
    box2: {
        paddingHorizontal: 40,
        justifyContent: 'space-evenly',
        marginTop: 20
    },
});